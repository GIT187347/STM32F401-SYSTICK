#ifndef _USART_H
#define _USART_H

#include "stm32f4xx.h"
#include <stdio.h>

extern u8 USART_BUFF[256];
 
 void USART1_Init(u32 bata);
void USART1_IQRhandler(void);
void USART1_Send(u8 data);
void USART1_SendString(u8 *data);
void priNTF(void);


#endif
