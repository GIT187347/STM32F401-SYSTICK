#ifndef _GPIO_H
#define _GPIO_H

#include "STM32F4xx.h"
#include "io_bit.h"
#include <stdio.h>

#define LED_G PBout(9)
#define LED_R PBout(8)
void LED_Init(void);


#endif

