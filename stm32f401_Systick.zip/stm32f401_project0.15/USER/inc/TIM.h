#ifndef _TIM_H
#define _TIM_H

#include "STM32F4XX.h"


void delay_Init();
void SysTick_Delay_ms(u32 nms);
void delay_us(u32 us);
void delay_ms(u16 ms);
void delay_1ms(u32 ms);
void delay_s(u8 s);
#endif
